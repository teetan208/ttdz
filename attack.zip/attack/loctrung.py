file_path = input('File: ')
unique_lines = set()

with open(file_path, 'r') as file:
    for line in file:
        if ':' in line:
            parts = line.strip().split(':')
            ip = parts[0]
            port = parts[1]
            proxy = ip + ':' + port
            unique_lines.add(proxy)

with open('proxies.txt', 'w') as output_file:
    for line in unique_lines:
        output_file.write(line + '\n')
